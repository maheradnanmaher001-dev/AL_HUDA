# AL-HUDA Step 18 — Quran & Hadith Data Integration

This step integrates **verified source data only**. No Quran or Hadith text is
generated, guessed, translated by code, or silently altered by this package.

## Required Quran coverage
- 114 Surahs
- 30 Juz/Paras
- Arabic text
- Urdu translation
- English translation
- Stable Surah/Ayah identifiers

## Required Hadith coverage
- Book/collection
- Hadith identifier/number
- Arabic text where licensed/available
- Urdu translation where licensed/available
- English translation where licensed/available
- Narrator (rawi) where available
- Grading/authentication field where provided by the source
- Source/reference metadata

## Verification rule
A dataset is not considered complete merely because a JSON file exists.
The final Step 18 verification must confirm coverage, required fields,
unique identifiers, valid JSON/UTF-8, and source/licensing metadata.

The workflow intentionally does not fabricate missing religious content.
If the repository does not yet contain the real datasets, the verification
job must stop instead of falsely marking Step 18 complete.
