"""AL-HUDA Step 18 content repository.

Read-only integration layer for verified Quran/Hadith content.
It does not invent or modify religious text. Data validation is performed
before content is exposed to the UI.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List


class ContentRepository:
    def __init__(self, data_root: str = "data") -> None:
        self.root = Path(data_root)

    def _load_json(self, path: Path) -> Any:
        with path.open("r", encoding="utf-8") as handle:
            return json.load(handle)

    def load_quran(self) -> Any:
        return self._load_first(
            ["quran.json", "quran/quran.json", "quran/data.json"]
        )

    def load_hadith(self) -> Any:
        return self._load_first(
            ["hadith.json", "hadith/hadith.json", "hadith/data.json"]
        )

    def _load_first(self, candidates: List[str]) -> Any:
        for relative in candidates:
            path = self.root / relative
            if path.is_file():
                return self._load_json(path)
        raise FileNotFoundError(
            "No supported content file found. Checked: "
            + ", ".join(candidates)
        )

    @staticmethod
    def is_non_empty_content(value: Any) -> bool:
        return bool(value) if isinstance(value, (dict, list)) else False

    def validate_presence(self) -> Dict[str, bool]:
        return {
            "quran": any(
                (self.root / p).is_file()
                for p in ["quran.json", "quran/quran.json", "quran/data.json"]
            ),
            "hadith": any(
                (self.root / p).is_file()
                for p in ["hadith.json", "hadith/hadith.json", "hadith/data.json"]
            ),
        }
