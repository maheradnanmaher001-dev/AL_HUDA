from pathlib import Path
from app.services.content_repository import ContentRepository


def test_repository_can_check_content_presence(tmp_path: Path):
    repo = ContentRepository(str(tmp_path))
    result = repo.validate_presence()
    assert result == {"quran": False, "hadith": False}
