from pathlib import Path
import ast
from PIL import Image

ROOT = Path(__file__).resolve().parent
spec = (ROOT/'buildozer.spec').read_text(encoding='utf-8')
assert 'title = AL-HUDA' in spec
assert 'package.name = alhuda' in spec
assert 'package.domain = org.alhuda' in spec
assert 'icon.filename = %(source.dir)s/assets/icon.png' in spec
assert 'source.include_exts = py,kv,png,jpg,jpeg,json,db,txt,md' in spec
assert 'android.api = 35' in spec
assert 'android.minapi = 23' in spec
assert 'android.archs = arm64-v8a,armeabi-v7a' in spec
for perm in ['INTERNET','ACCESS_FINE_LOCATION','ACCESS_COARSE_LOCATION','POST_NOTIFICATIONS','WAKE_LOCK','FOREGROUND_SERVICE']:
    assert perm in spec, perm
icon=Image.open(ROOT/'assets/icon.png')
assert icon.width >= 512 and icon.height >= 512
for p in [ROOT/'main.py'] + list((ROOT/'app').rglob('*.py')) + list((ROOT/'backend').rglob('*.py')):
    ast.parse(p.read_text(encoding='utf-8'), filename=str(p))
print('PASS: AL-HUDA app label')
print('PASS: package/icon/build configuration')
print('PASS: Android permissions')
print('PASS: icon >= 512x512')
print('PASS: Python syntax')
