# AL-HUDA Step 18

Upload `AL_HUDA_STEP18_DATA_PACKAGE.zip` to the repository ROOT.

The workflow then:
1. Finds the ZIP.
2. Extracts the downloader into `tools/`.
3. Checks Python syntax.
4. Downloads the complete local Quran/Hadith data.
5. Verifies the generated files.
6. Commits the verified local data to `data/`.

Do not manually create the `tools` folder.
