from pathlib import Path
import ast

ROOT = Path(__file__).resolve().parents[1]
required = [
    ROOT / 'app/utils/responsive.py',
    ROOT / 'app/screens/settings.py',
    ROOT / 'app/screens/common.py',
    ROOT / 'al_huda.kv',
    ROOT / 'STEP19_RESPONSIVE_SPEC.md',
]
for p in required:
    assert p.is_file(), f'Missing required Step 19 file: {p}'

for p in ROOT.joinpath('app').rglob('*.py'):
    ast.parse(p.read_text(encoding='utf-8'), filename=str(p))

responsive = (ROOT / 'app/utils/responsive.py').read_text(encoding='utf-8')
settings = (ROOT / 'app/screens/settings.py').read_text(encoding='utf-8')
common = (ROOT / 'app/screens/common.py').read_text(encoding='utf-8')
kv = (ROOT / 'al_huda.kv').read_text(encoding='utf-8')
spec = (ROOT / 'STEP19_RESPONSIVE_SPEC.md').read_text(encoding='utf-8')

assert 'MIN_TEXT_SCALE = 0.80' in responsive
assert 'MAX_TEXT_SCALE = 1.60' in responsive
assert 'STEP = 0.10' in responsive
assert 'def get_text_scale' in responsive
assert 'def set_text_scale' in responsive
assert 'JsonStore' in responsive
assert 'def adaptive_dp' in responsive
assert 'Window.bind(on_resize=_on_resize)' in responsive
assert 'set_text_scale' in settings
assert 'get_text_scale' in settings
assert 'MIN_TEXT_SCALE' in settings and 'MAX_TEXT_SCALE' in settings
assert 'fs' in common
assert '#:import fs app.utils.responsive.fs' in kv
assert 'fs(10)' in kv
assert 'responsive' in spec.lower()
assert 'text size' in spec.lower()

print('PASS: Step 19 source/AST verification completed without requiring Kivy on CI runner.')
