# AL-HUDA Step 18 — Complete Local Quran & Hadith Data

This package fixes the previous Step 18 failure where the workflow referenced a missing
`tools/download_step18_data.py`.

## Included
- `tools/download_step18_data.py` — downloader + verifier
- `.github/workflows/extract-al-huda-step18.yml` — GitHub Actions workflow
- empty `data/quran/` and `data/hadith/` directories for package structure

## Workflow behavior
1. Checks that the downloader exists and compiles it before running.
2. Downloads the complete Arabic Quran dataset (114 surahs / 6,236 ayahs / 30 juz).
3. Downloads complete English and Urdu Quran editions.
4. Downloads all Arabic/English/Urdu Hadith editions listed by the Hadith API catalogue.
5. Verifies files are non-empty and structurally valid.
6. Writes `data/STEP18_MANIFEST.json` with SHA-256 hashes.
7. Commits the generated local data to the repository only after all verification passes.

The generated Quran/Hadith data is local to the repository after the workflow succeeds;
the final APK will still need Step 19 integration to read these local files.
