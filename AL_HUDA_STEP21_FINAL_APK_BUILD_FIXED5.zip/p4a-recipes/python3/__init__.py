"""AL-HUDA Android-safe Python 3 recipe override.

The upstream CPython grp extension can be selected during Android cross
compilation even though Android/Bionic does not provide getgrent().
Force configure to treat getgrent as unavailable so CPython skips grp.
AL-HUDA does not import grp, so this safely removes an unsupported stdlib
extension from the APK build.
"""

from pythonforandroid.recipes.python3 import Python3Recipe


class AlHudaPython3Recipe(Python3Recipe):
    name = "python3"
    version = "3.13.12"
    configure_args = list(Python3Recipe.configure_args) + [
        "ac_cv_func_getgrent=no",
    ]
    # NOTE: Python3Recipe.patches lists patch files with paths relative to
    # the recipe's own directory (e.g. "patches/reproducible-buildinfo.diff").
    # Because this is a *local* recipe override, p4a resolves those paths
    # against this folder (p4a-recipes/python3/) instead of the upstream
    # python-for-android recipe folder, and the patches/ subfolder was never
    # copied here -> "No such file or directory" build failure.
    # These patches are reproducibility/cosmetic fixes, not required for a
    # working build, so we safely disable them for this local override.
    patches = []


recipe = AlHudaPython3Recipe()
