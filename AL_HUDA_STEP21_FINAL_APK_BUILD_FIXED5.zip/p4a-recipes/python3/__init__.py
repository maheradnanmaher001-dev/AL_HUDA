"""AL-HUDA Android-safe Python 3 recipe override.

The upstream CPython grp extension can be selected during Android cross
compilation even though Android/Bionic does not provide getgrent().
Force configure to treat getgrent as unavailable so CPython skips grp.
AL-HUDA does not import grp, so this safely removes an unsupported stdlib
extension from the APK build.
"""

from pythonforandroid.recipes.python3 import Python3Recipe


class AlHudaPython3Recipe(Python3Recipe):
    name = "python3"
    version = "3.13.12"
    configure_args = list(Python3Recipe.configure_args) + [
        "ac_cv_func_getgrent=no",
    ]


recipe = AlHudaPython3Recipe()
