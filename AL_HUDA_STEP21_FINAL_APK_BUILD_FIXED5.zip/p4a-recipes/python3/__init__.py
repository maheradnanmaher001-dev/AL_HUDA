"""AL-HUDA Android-safe Python 3 recipe override.

The upstream CPython grp extension can be selected during Android cross
compilation even though Android/Bionic does not provide getgrent().
Force configure to treat getgrent as unavailable so CPython skips grp.
AL-HUDA does not import grp, so this safely removes an unsupported stdlib
extension from the APK build.
"""

from pythonforandroid.recipes.python3 import Python3Recipe


class AlHudaPython3Recipe(Python3Recipe):
    name = "python3"
    version = "3.13.12"
    configure_args = list(Python3Recipe.configure_args) + [
        "ac_cv_func_getgrent=no",
    ]
    # NOTE: Python3Recipe ships several patch files under its own
    # patches/ folder (paths relative to the recipe's directory, e.g.
    # "patches/reproducible-buildinfo.diff", "patches/cpython-311-ctypes-
    # find-library.patch", etc). Because this is a *local* recipe override,
    # p4a resolves those relative paths against THIS folder
    # (p4a-recipes/python3/) instead of the upstream python-for-android
    # recipe folder -- and the patches/ subfolder was never copied here,
    # so every one of them fails with "No such file or directory"
    # (known p4a limitation: https://github.com/kivy/python-for-android/issues/2623).
    # Overriding the apply_patches() method itself (rather than just the
    # `patches` list) guarantees no patch is ever attempted here, no matter
    # what the upstream list contains or how it changes between p4a
    # versions. We only need this local recipe for the configure_args
    # tweak above, so skipping the upstream patches is safe for this build.
    def apply_patches(self, arch, build_dir=None):
        return


recipe = AlHudaPython3Recipe()
