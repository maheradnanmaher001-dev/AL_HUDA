from pathlib import Path
import ast
import struct

ROOT = Path(__file__).resolve().parent
spec = (ROOT / 'buildozer.spec').read_text(encoding='utf-8')
assert 'title = AL-HUDA' in spec
assert 'package.name = alhuda' in spec
assert 'package.domain = org.alhuda' in spec
assert 'icon.filename = %(source.dir)s/assets/icon.png' in spec
assert 'presplash.filename = %(source.dir)s/assets/splash.png' in spec
assert 'source.include_exts = py,kv,png,jpg,jpeg,json,db,txt,md' in spec
assert 'android.api = 35' in spec
assert 'android.minapi = 23' in spec
assert 'android.archs = arm64-v8a,armeabi-v7a' in spec
for perm in ['INTERNET','ACCESS_FINE_LOCATION','ACCESS_COARSE_LOCATION','POST_NOTIFICATIONS','WAKE_LOCK','FOREGROUND_SERVICE']:
    assert perm in spec, perm

def png_dimensions(path: Path):
    with path.open('rb') as fh:
        assert fh.read(8) == b'\x89PNG\r\n\x1a\n', f'{path} is not a valid PNG'
        length = struct.unpack('>I', fh.read(4))[0]
        assert fh.read(4) == b'IHDR', f'{path}: PNG IHDR chunk missing'
        assert length >= 8, f'{path}: PNG IHDR chunk too small'
        return struct.unpack('>II', fh.read(8))

icon_w, icon_h = png_dimensions(ROOT / 'assets/icon.png')
splash_w, splash_h = png_dimensions(ROOT / 'assets/splash.png')
assert icon_w >= 512 and icon_h >= 512, f'icon too small: {icon_w}x{icon_h}'
assert splash_w >= 512 and splash_h >= 512, f'splash too small: {splash_w}x{splash_h}'

for p in [ROOT / 'main.py'] + list((ROOT / 'app').rglob('*.py')) + list((ROOT / 'backend').rglob('*.py')):
    ast.parse(p.read_text(encoding='utf-8'), filename=str(p))

print('PASS: AL-HUDA app label')
print('PASS: package/build configuration')
print('PASS: Android permissions')
print(f'PASS: icon PNG {icon_w}x{icon_h}')
print(f'PASS: splash PNG {splash_w}x{splash_h}')
print('PASS: Python syntax')


# Step 21 build-environment guard: use matched Python/hostpython 3.13 and
# an Android-safe local recipe that disables the unsupported grp extension.
spec_requirements = next(
    line.split("=", 1)[1].strip()
    for line in spec.splitlines()
    if line.strip().startswith("requirements") and "=" in line
)
assert 'python3==3.13.12' in spec_requirements and 'hostpython3==3.13.12' in spec_requirements, (
    'Step 21 requires matched Python/hostpython 3.13.12.'
)
recipe = (ROOT / 'p4a-recipes/python3/__init__.py').read_text(encoding='utf-8')
assert 'ac_cv_func_getgrent=no' in recipe
assert 'version = \"3.13.12\"' in recipe
assert 'pythonforandroid.recipes.python3' in recipe
print('PASS: custom Android-safe Python 3 recipe disables unsupported grp extension')
