# AL-HUDA Changelog

## Step 8
- Added Duas & Azkar service
- Added Arabic, Urdu, English and reference fields
- Added categories foundation
- Added Dua search
- Added Dua screen
- Added project roadmap for continuity
\n## Step 9\n- Added persistent Tasbeeh counter, 33/99 targets, Dhikr presets, progress, reset, vibration toggle and tap animation.\n
## Step 10
- Added universal search service
- Added Quran/Hadith/Dua sections
- Added search result rendering
- Added section filters
- Updated project roadmap

## Step 11
- Added persistent bookmarks storage
- Added history storage with a 100-item limit
- Added bookmarks/history screen
- Added clear history control
- Updated project roadmap
