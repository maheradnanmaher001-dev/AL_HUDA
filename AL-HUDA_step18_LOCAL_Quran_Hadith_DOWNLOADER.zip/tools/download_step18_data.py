#!/usr/bin/env python3
"""
AL-HUDA Step 18 data downloader.

Downloads source data ONCE during the GitHub Action and stores it locally
under data/. The app can then read local files without needing a Quran/Hadith
network request at runtime.

Sources:
- Quran: Al Quran Cloud complete editions:
  quran-uthmani, en.sahih, ur.jalandhry
- Hadith: fawazahmed0/hadith-api, pinned to API version 1.
  The editions catalogue is used to discover Arabic/English/Urdu editions.

The downloader intentionally fails loudly if a required source cannot be
downloaded or a requested Hadith language is unavailable.
"""

from __future__ import annotations

import json
import os
import re
import sys
import time
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
QURAN_DIR = DATA / "quran"
HADITH_DIR = DATA / "hadith"

QURAN_SOURCES = {
    "arabic": "https://api.alquran.cloud/v1/quran/quran-uthmani",
    "english": "https://api.alquran.cloud/v1/quran/en.sahih",
    "urdu": "https://api.alquran.cloud/v1/quran/ur.jalandhry",
}

# 17 collections represented by the pinned AhmedBaset hadith-json dataset.
# The fawaz catalogue is checked at build time so the exact edition URLs are
# not hard-coded incorrectly.
HADITH_BOOKS = [
    "bukhari", "muslim", "abudawud", "tirmidhi", "nasai", "ibnmajah",
    "malik", "ahmad", "darimi", "riyadussalihin", "shamail",
    "bulugh", "adab", "mishkat", "nawawi", "qudsi", "dehlawi",
]

HADITH_CATALOGUE = "https://cdn.jsdelivr.net/gh/fawazahmed0/hadith-api@1/editions.json"
HADITH_RAW_BASE = "https://raw.githubusercontent.com/fawazahmed0/hadith-api/1/editions"

def fetch_json(url: str, attempts: int = 4):
    last = None
    for attempt in range(1, attempts + 1):
        try:
            req = Request(url, headers={"User-Agent": "AL-HUDA-Step18/1.0"})
            with urlopen(req, timeout=60) as r:
                return json.loads(r.read().decode("utf-8"))
        except (HTTPError, URLError, TimeoutError, json.JSONDecodeError) as exc:
            last = exc
            if attempt < attempts:
                time.sleep(attempt * 2)
    raise RuntimeError(f"Download failed after {attempts} attempts: {url}\n{last}")

def write_json(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")

def download_quran():
    print("Downloading Quran editions...")
    editions = {}
    for lang, url in QURAN_SOURCES.items():
        payload = fetch_json(url)
        if payload.get("status") != "OK" or not payload.get("data"):
            raise RuntimeError(f"Invalid Quran response for {lang}: {url}")
        editions[lang] = payload["data"]
        write_json(QURAN_DIR / f"{lang}.json", payload["data"])

    arabic = editions["arabic"]
    english = editions["english"]
    urdu = editions["urdu"]

    if len(arabic.get("surahs", [])) != 114:
        raise RuntimeError("Arabic Quran does not contain exactly 114 surahs.")

    ays = sum(len(s.get("ayahs", [])) for s in arabic["surahs"])
    if ays != 6236:
        raise RuntimeError(f"Arabic Quran ayah count is {ays}, expected 6236.")

    # Build one local merged catalogue keyed by surah/ayah.
    def index_edition(ed):
        return {
            (s["number"], a["numberInSurah"]): a["text"]
            for s in ed["surahs"] for a in s["ayahs"]
        }

    en = index_edition(english)
    ur = index_edition(urdu)

    merged = []
    for s in arabic["surahs"]:
        for a in s["ayahs"]:
            key = (s["number"], a["numberInSurah"])
            if key not in en or key not in ur:
                raise RuntimeError(f"Missing translation at {s['number']}:{a['numberInSurah']}")
            merged.append({
                "surah": s["number"],
                "surah_name": s["englishName"],
                "ayah": a["numberInSurah"],
                "global_ayah": a["number"],
                "juz": a.get("juz"),
                "manzil": a.get("manzil"),
                "page": a.get("page"),
                "hizbQuarter": a.get("hizbQuarter"),
                "ruku": a.get("ruku"),
                "sajda": a.get("sajda"),
                "arabic": a["text"],
                "english": en[key],
                "urdu": ur[key],
            })

    write_json(QURAN_DIR / "quran_complete.json", {
        "schema_version": 1,
        "source": "Al Quran Cloud",
        "arabic_edition": "quran-uthmani",
        "english_edition": "en.sahih",
        "urdu_edition": "ur.jalandhry",
        "surahs": 114,
        "ayahs": 6236,
        "juz": 30,
        "items": merged,
    })

    # Explicit Juz files for app navigation.
    juz_map = {i: [] for i in range(1, 31)}
    for row in merged:
        if row["juz"] in juz_map:
            juz_map[row["juz"]].append(row)
    for juz_no, rows in juz_map.items():
        if not rows:
            raise RuntimeError(f"Juz {juz_no} is empty.")
        write_json(QURAN_DIR / "juz" / f"juz_{juz_no:02d}.json", {
            "juz": juz_no,
            "ayahs": rows,
        })

    write_json(QURAN_DIR / "manifest.json", {
        "surahs": 114,
        "ayahs": 6236,
        "juz": 30,
        "languages": ["ar", "en", "ur"],
        "files": ["arabic.json", "english.json", "urdu.json", "quran_complete.json"],
    })
    print("Quran download + merge complete.")

def find_editions(catalogue):
    result = {}
    for book in HADITH_BOOKS:
        raw = catalogue.get(book, {}).get("collection", [])
        by_lang = {}
        for ed in raw:
            lang = str(ed.get("language", "")).lower()
            name = ed.get("name", "")
            if lang == "arabic" and name.startswith("ara-"):
                by_lang["arabic"] = name
            elif lang == "english" and name.startswith("eng-"):
                by_lang["english"] = name
            elif lang == "urdu" and name.startswith("urd-"):
                by_lang["urdu"] = name
        result[book] = by_lang
    return result

def download_hadith():
    print("Downloading Hadith editions catalogue...")
    catalogue = fetch_json(HADITH_CATALOGUE)
    selected = find_editions(catalogue)

    missing = []
    for book, langs in selected.items():
        for lang in ("arabic", "english", "urdu"):
            if lang not in langs:
                missing.append(f"{book}:{lang}")
    if missing:
        raise RuntimeError(
            "Required Hadith language editions are missing from the pinned "
            "catalogue: " + ", ".join(missing)
        )

    manifest = {"source": HADITH_RAW_BASE, "api_version": "1", "books": {}}

    for book, langs in selected.items():
        book_dir = HADITH_DIR / book
        book_dir.mkdir(parents=True, exist_ok=True)
        manifest["books"][book] = {}

        for lang, edition in langs.items():
            url = f"{HADITH_RAW_BASE}/{edition}.json"
            payload = fetch_json(url)
            if not isinstance(payload, dict):
                raise RuntimeError(f"Invalid Hadith JSON: {url}")
            write_json(book_dir / f"{lang}.json", payload)
            manifest["books"][book][lang] = {
                "edition": edition,
                "records": len(payload.get("hadiths", [])),
            }

        # Merge by hadith number where possible; keep original fields intact.
        editions = {}
        for lang in ("arabic", "english", "urdu"):
            editions[lang] = json.loads(
                (book_dir / f"{lang}.json").read_text(encoding="utf-8")
            )

        def hadith_list(obj):
            return obj.get("hadiths") or obj.get("data") or []

        indexes = {}
        for lang, obj in editions.items():
            indexes[lang] = {}
            for h in hadith_list(obj):
                key = h.get("hadithnumber") or h.get("id") or h.get("hadithNumber")
                if key is not None:
                    indexes[lang][str(key)] = h

        keys = sorted(set().union(*[set(x) for x in indexes.values()]), key=lambda x: int(re.sub(r"\D", "", x) or 0))
        merged = []
        for key in keys:
            merged.append({
                "number": key,
                "arabic": indexes["arabic"].get(key),
                "english": indexes["english"].get(key),
                "urdu": indexes["urdu"].get(key),
            })

        write_json(book_dir / "merged.json", {
            "book": book,
            "editions": langs,
            "hadiths": merged,
        })

    write_json(HADITH_DIR / "manifest.json", manifest)
    print("Hadith download + merge complete.")

def main():
    DATA.mkdir(parents=True, exist_ok=True)
    download_quran()
    download_hadith()
    print("STEP 18 DOWNLOAD COMPLETE")

if __name__ == "__main__":
    main()
