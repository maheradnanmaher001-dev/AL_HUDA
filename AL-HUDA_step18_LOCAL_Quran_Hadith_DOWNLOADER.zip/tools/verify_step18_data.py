#!/usr/bin/env python3
"""Strict local Step 18 verifier. No network/API calls are used here."""

from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
Q = ROOT / "data" / "quran"
H = ROOT / "data" / "hadith"

def load(p):
    return json.loads(p.read_text(encoding="utf-8"))

def verify_quran():
    p = Q / "quran_complete.json"
    if not p.exists():
        raise SystemExit("FAIL: data/quran/quran_complete.json is missing")

    d = load(p)
    if d.get("surahs") != 114:
        raise SystemExit(f"FAIL: Quran surahs={d.get('surahs')}, expected 114")
    if d.get("ayahs") != 6236:
        raise SystemExit(f"FAIL: Quran ayahs={d.get('ayahs')}, expected 6236")
    if d.get("juz") != 30:
        raise SystemExit(f"FAIL: Quran juz={d.get('juz')}, expected 30")

    items = d.get("items", [])
    if len(items) != 6236:
        raise SystemExit(f"FAIL: merged Quran records={len(items)}, expected 6236")

    for i, row in enumerate(items, 1):
        for field in ("arabic", "english", "urdu"):
            if not isinstance(row.get(field), str) or not row[field].strip():
                raise SystemExit(f"FAIL: missing Quran {field} text at record {i}")

    for n in range(1, 31):
        p = Q / "juz" / f"juz_{n:02d}.json"
        if not p.exists():
            raise SystemExit(f"FAIL: missing Juz file {n}")
        if not load(p).get("ayahs"):
            raise SystemExit(f"FAIL: empty Juz file {n}")

    print("PASS: Quran = 114 Surahs / 6236 Ayahs / 30 Juz / Arabic+English+Urdu")

def verify_hadith():
    manifest = H / "manifest.json"
    if not manifest.exists():
        raise SystemExit("FAIL: Hadith manifest missing")
    d = load(manifest)
    books = d.get("books", {})
    if len(books) != 17:
        raise SystemExit(f"FAIL: Hadith books={len(books)}, expected 17")

    total = 0
    for book in books:
        merged = H / book / "merged.json"
        if not merged.exists():
            raise SystemExit(f"FAIL: missing merged Hadith file: {book}")
        rows = load(merged).get("hadiths", [])
        if not rows:
            raise SystemExit(f"FAIL: empty Hadith book: {book}")
        total += len(rows)
        for row in rows:
            if not row.get("number"):
                raise SystemExit(f"FAIL: missing Hadith number in {book}")
            if not any(row.get(lang) for lang in ("arabic", "english", "urdu")):
                raise SystemExit(f"FAIL: empty Hadith record in {book}")

    print(f"PASS: Hadith = {len(books)} books / {total} merged numbered records")

def main():
    verify_quran()
    verify_hadith()
    print("STEP 18 LOCAL DATA VERIFICATION PASSED")

if __name__ == "__main__":
    main()
