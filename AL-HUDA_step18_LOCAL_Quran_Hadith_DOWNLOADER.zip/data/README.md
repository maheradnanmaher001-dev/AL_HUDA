# AL-HUDA Step 18 — Local Quran + Hadith Data

This package is intentionally a **downloader + verifier**, not a fake tiny
"data ZIP". GitHub Actions downloads the actual datasets from pinned/open
sources, saves them under `data/`, verifies them locally, and commits them.

## What it downloads

### Quran
- 114 Surahs
- 6,236 Ayahs
- 30 Juz
- Arabic: `quran-uthmani`
- English: `en.sahih`
- Urdu: `ur.jalandhry`
- A merged `quran_complete.json`
- Individual Juz files

### Hadith
17 collections, with Arabic + English + Urdu editions where the pinned
catalogue provides them. The workflow fails instead of silently substituting
missing language data.

## Important

The data is downloaded during the GitHub Action and then committed into the
repository. After that, the app can read the local `data/` files and does not
need to fetch Quran/Hadith text at runtime.

Run the workflow manually from GitHub Actions:
**Actions → Step 18 - Download and Verify Quran Hadith Data → Run workflow**

Do not use the previous Step 18 verification workflow at the same time.
