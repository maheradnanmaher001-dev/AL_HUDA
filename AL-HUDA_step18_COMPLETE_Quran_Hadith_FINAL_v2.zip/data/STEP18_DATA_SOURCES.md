# Step 18 data-source requirements
- Complete Quran source: Al Quran Cloud
- Complete Hadith source: fawazahmed0/hadith-api editions
- No fabricated religious text
- Source identifiers preserved
- Runtime cache stored under data/quran_cache and data/hadith_cache
