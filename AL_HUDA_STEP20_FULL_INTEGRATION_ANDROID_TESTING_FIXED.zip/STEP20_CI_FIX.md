Step 20 CI fix: the GitHub workflow performs the integration audit inline and does not depend on tools/verify_step20.py being copied into the checkout.
