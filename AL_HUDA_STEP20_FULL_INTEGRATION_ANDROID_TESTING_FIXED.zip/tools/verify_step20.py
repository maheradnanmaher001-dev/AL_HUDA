from pathlib import Path
import ast
import re

ROOT = Path(__file__).resolve().parents[1]

REQUIRED_SCREENS = {
    "SplashScreen": "app/screens/splash.py",
    "LoginScreen": "app/screens/auth.py",
    "RegisterScreen": "app/screens/auth.py",
    "VerifyScreen": "app/screens/auth.py",
    "ForgotPasswordScreen": "app/screens/auth.py",
    "ResetPasswordScreen": "app/screens/auth.py",
    "HomeScreen": "app/screens/home.py",
    "QuranScreen": "app/screens/quran.py",
    "QuranReaderScreen": "app/screens/quran.py",
    "HadithScreen": "app/screens/hadith.py",
    "HadithDetailScreen": "app/screens/hadith.py",
    "PrayerScreen": "app/screens/prayer.py",
    "QiblaScreen": "app/screens/qibla.py",
    "SearchScreen": "app/screens/search.py",
    "DuaScreen": "app/screens/dua.py",
    "TasbeehScreen": "app/screens/tasbeeh.py",
    "CalendarScreen": "app/screens/calendar.py",
    "RamadanScreen": "app/screens/ramadan.py",
    "BookmarksScreen": "app/screens/bookmarks.py",
    "SettingsScreen": "app/screens/settings.py",
}


def read(path):
    return (ROOT / path).read_text(encoding="utf-8")


def assert_file(path):
    p = ROOT / path
    assert p.is_file(), f"Missing required file: {path}"
    return p


def main():
    # Core files.
    for path in [
        "main.py", "al_huda.kv", "buildozer.spec", "requirements.txt",
        "app/database.py", "app/theme.py", "app/utils/responsive.py",
        "app/services/quran_service.py", "app/services/hadith_service.py",
        "app/services/prayer.py", "app/services/qibla.py", "app/services/adhan.py",
        "STEP18_MANIFEST.txt", "STEP20_INTEGRATION_TESTING.md",
    ]:
        assert_file(path)

    # Parse every Python source without importing Kivy.
    for p in ROOT.rglob("*.py"):
        if ".step20_package" in p.parts:
            continue
        ast.parse(p.read_text(encoding="utf-8"), filename=str(p))

    main_py = read("main.py")
    for cls in REQUIRED_SCREENS:
        assert re.search(rf"\b{re.escape(cls)}\b", main_py), f"{cls} not registered in main.py"

    # Responsive/text-size integration from Step 19.
    responsive = read("app/utils/responsive.py")
    settings = read("app/screens/settings.py")
    common = read("app/screens/common.py")
    kv = read("al_huda.kv")
    for token in ["MIN_TEXT_SCALE = 0.80", "MAX_TEXT_SCALE = 1.60", "STEP = 0.10", "def fs(", "def set_text_scale("]:
        assert token in responsive, f"Responsive token missing: {token}"
    assert "set_text_scale" in settings
    assert "from app.utils.responsive import fs" in common
    assert "fs(10)" in kv

    # Quran/Hadith service contracts.
    quran = read("app/services/quran_service.py")
    for token in ["SURAH_COUNT = 114", "JUZ_COUNT = 30", "def get_surah(", "def get_juz(", "def get_juz_with_translations(", "def search_quran("]:
        assert token in quran, f"Quran integration token missing: {token}"
    hadith = read("app/services/hadith_service.py")
    for token in ["def editions(", "def book(", "def hadith(", "def section(", "def normalize("]:
        assert token in hadith, f"Hadith integration token missing: {token}"

    # Local persistence + Android configuration.
    # The upload package intentionally excludes data/ so it cannot overwrite the
    # repository's real Quran/Hadith dataset. When data/ is present, verify its
    # expected directories; otherwise leave it untouched.
    if (ROOT / "data").exists():
        assert (ROOT / "data/quran").is_dir(), "data/quran directory missing"
        assert (ROOT / "data/hadith").is_dir(), "data/hadith directory missing"
    buildozer = read("buildozer.spec")
    for token in [
        "requirements = python3,kivy,requests",
        "android.api = 35",
        "android.minapi = 23",
        "ACCESS_FINE_LOCATION",
        "ACCESS_COARSE_LOCATION",
        "POST_NOTIFICATIONS",
        "WAKE_LOCK",
        "FOREGROUND_SERVICE",
    ]:
        assert token in buildozer, f"Android/build config missing: {token}"

    # Step 20 verification script itself must not import Kivy.
    verify_tree = ast.parse(read("tools/verify_step20.py"), filename="tools/verify_step20.py")
    for node in ast.walk(verify_tree):
        if isinstance(node, ast.Import):
            assert all(alias.name != "kivy" and not alias.name.startswith("kivy.") for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            assert node.module != "kivy" and not (node.module or "").startswith("kivy.")

    print("PASS: all required AL-HUDA screens are registered")
    print("PASS: all Python sources parse without Kivy runtime")
    print("PASS: Step 18 Quran/Hadith service contracts present")
    print("PASS: Step 19 responsive/text-size integration preserved")
    print("PASS: local data directories preserved")
    print("PASS: Android Buildozer configuration audited")
    print("PASS: Step 20 integration verification complete")


if __name__ == "__main__":
    main()
